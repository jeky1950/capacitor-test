import{b as e,et as t,mt as n,xt as r}from"./CoKk4mC0.js";import{r as i}from"./Oe5uePVp.js";import{t as a}from"./C5STy1Vp.js";import{t as o}from"./DYMBtyPU.js";var s={name:`CheckboxGroup`,extends:{name:`BaseCheckboxGroup`,extends:o,style:i.extend({name:`checkboxgroup`,style:`
    .p-checkbox-group {
        display: inline-flex;
    }
`,classes:{root:`p-checkbox-group p-component`}}),provide:function(){return{$pcCheckboxGroup:this,$parentInstance:this}}},inheritAttrs:!1,data:function(){return{groupName:this.name}},watch:{name:function(e){this.groupName=e||a(`checkbox-group-`)}},mounted:function(){this.groupName=this.groupName||a(`checkbox-group-`)}};function c(i,a,o,s,c,l){return n(),e(`div`,t({class:i.cx(`root`)},i.ptmi(`root`)),[r(i.$slots,`default`)],16)}s.render=c;export{s as default};