import{D as e,St as t,b as n,et as r,mt as i,xt as a}from"./CoKk4mC0.js";import{r as o}from"./Oe5uePVp.js";import{t as s}from"./CV5VfT8N.js";var c={name:`OverlayBadge`,extends:{name:`OverlayBadge`,extends:s,style:o.extend({name:`overlaybadge`,style:`
    .p-overlaybadge {
        position: relative;
    }

    .p-overlaybadge .p-badge {
        position: absolute;
        inset-block-start: 0;
        inset-inline-end: 0;
        transform: translate(50%, -50%);
        transform-origin: 100% 0;
        margin: 0;
        outline-width: dt('overlaybadge.outline.width');
        outline-style: solid;
        outline-color: dt('overlaybadge.outline.color');
    }

    .p-overlaybadge .p-badge:dir(rtl) {
        transform: translate(-50%, -50%);
    }
`,classes:{root:`p-overlaybadge`}}),provide:function(){return{$pcOverlayBadge:this,$parentInstance:this}}},inheritAttrs:!1,components:{Badge:s}};function l(o,s,c,l,u,d){var f=t(`Badge`);return i(),n(`div`,r({class:o.cx(`root`)},o.ptmi(`root`)),[a(o.$slots,`default`),e(f,r(o.$props,{pt:o.ptm(`pcBadge`)}),null,16,[`pt`])],16)}c.render=l;export{c as default};